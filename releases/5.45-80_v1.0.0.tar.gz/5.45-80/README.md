# InterProScan

Documentation for the version of InterProScan is hosted by ReadtheDocs: https://agbase-docs.readthedocs.io/en/latest/ . 

You can pull this image from docker hub with this command
```
docker pull agbase/interproscan:5.45-80
```
