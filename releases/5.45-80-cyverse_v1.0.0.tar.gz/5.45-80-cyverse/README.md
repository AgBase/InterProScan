# InterProScan

This version is optimized for execution in the Cyverse environment.
